<?php
/**
 * Created by PhpStorm.
 * User: yuriy
 * Date: 11/14/17
 * Time: 3:36 PM
 */

namespace config;

class Constants
{
    const DEBUG_MODE = true;
    const DEFAULT_ROUTE = 'index/index';

    const MYSQL_HOST = 'localhost';
    const MYSQL_USER = 'root';
    const MYSQL_PASSWORD = '001985';
    const MYSQL_DB_NAME = 'test';

    const TASK_PER_PAGE = 3;
    const SITE_SCHEMA = 'http';
}