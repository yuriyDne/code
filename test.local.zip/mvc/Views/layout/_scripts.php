<?php foreach ($jsScripts as $jsScript): ?>
    <script src="<?=$jsScript;?>"></script>
<?php endforeach; ?>
<?php foreach ($cssScripts as $cssScript):?>
    <link rel="stylesheet" href="<?=$cssScript;?>">
<?php endforeach; ?>
