<?php

namespace mvc\Enum;

use MyCLabs\Enum\Enum;

class FileType extends Enum
{
    const JS = 'js';
    const CSS = 'css';
}